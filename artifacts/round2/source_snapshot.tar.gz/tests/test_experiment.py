import numpy as np
import torch
from crowbrain.task import Bank, balanced_pairs, draw_dots
from crowbrain.model import VisualRNN
from crowbrain.analysis import decode, tuning

def test_balance():
    pairs=balanced_pairs(3)
    y=pairs[:,0]==pairs[:,1]
    assert y.mean()==.5
    for axis in (0,1):
        for k in range(5): assert y[pairs[:,axis]==k].mean()==.5

def test_independent_images():
    bank=Bank(1,10)
    a,b,y,*_=bank.batch(np.random.default_rng(1),pairs=balanced_pairs(2))
    assert not torch.any(torch.all(a==b,dim=(1,2,3)))
    other=Bank(2,10)
    assert not torch.equal(bank.images,other.images)

def test_dots_and_protocols():
    from scipy.ndimage import label
    rng=np.random.default_rng(3)
    for mode in ['standard','area','shift']:
        for n in range(2,7):
            for _ in range(20):
                im,s=draw_dots(n,rng,mode)
                assert label(im>.5)[1]==n
                assert np.isfinite(s).all()

def test_reset_removes_sample_dependency():
    torch.manual_seed(1)
    m=VisualRNN()
    a=torch.rand(4,1,32,32); b=torch.rand_like(a)
    assert torch.equal(m(a,b,reset=True),m(a.flip(0),b,reset=True))

def test_dale_signs_and_gradients():
    m=VisualRNN(kind='ei')
    optimizer=torch.optim.Adam(m.parameters(),lr=.01)
    for _ in range(3):
        loss=m(torch.rand(4,1,32,32),torch.rand(4,1,32,32)).square().mean()
        optimizer.zero_grad(); loss.backward(); optimizer.step()
        w=m.weights()
        assert torch.all(w[:,m.signs>0]>=0)
        assert torch.all(w[:,m.signs<0]<=0)

def test_analysis_positive_negative_controls():
    rng=np.random.default_rng(2)
    y=np.repeat(np.arange(5),100)
    center=np.arange(5)[None,:]
    a=np.exp(-((y[:,None]-center)**2)/.6)+rng.normal(0,.03,(500,5))
    b=np.exp(-((y[:,None]-center)**2)/.6)+rng.normal(0,.03,(500,5))
    assert decode(a,y,b,y)>.95
    t=tuning(a,y,b,y)
    assert t['interior_peaked_fraction']==.6
    noise=rng.normal(size=(500,64)); noise2=rng.normal(size=(500,64))
    assert decode(noise,y,noise2,y)<.3
    assert tuning(noise,y,noise2,y)['interior_peaked_fraction']<.05
